package com.carpark.exception;

public class DeleteParkingException extends Exception{

	

	public DeleteParkingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

		
}
